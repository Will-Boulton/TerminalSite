﻿window.SetFocusToElement = (element) => {
         element.focus();
};