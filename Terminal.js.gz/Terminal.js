﻿window.SetFocusToElement = (element) => {
         element.focus();
};


window.ScrollToBottom = (e) => {
    e.scrollTop = e.scrollHeight;
};
